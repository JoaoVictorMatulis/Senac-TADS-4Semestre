function adicionar(valor){
    alert(valor)/*
    var tr = document.createElement("tr");
    var td = [document.createElement("td"),document.createElement("td"),document.createElement("td")]
    let nome = document.createTextNode(prompt("Digite o nome do Funcionario"));
    let salario = prompt("Digite seu salário atual");
    let salarionovo = salario * 1.25
    salario = document.createTextNode(salario);
    salarionovo = document.createTextNode(salarionovo);
    td[0].appendChild(nome)
    td[1].appendChild(salario)
    td[2].appendChild(salarionovo)
    for(let i = 0 ; i<3 ; i++){
        tr.appendChild(td[i])
    }
    var element = document.getElementById('id_2')
    element.parentNode.insertBefore(tr, element)*/
}