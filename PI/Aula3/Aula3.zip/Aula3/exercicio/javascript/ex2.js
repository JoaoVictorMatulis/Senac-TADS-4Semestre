let nota1 = prompt("Digite a 1º nota:");
nota1=eval(nota1)
let nota2 = prompt("Digite a 2º nota:");
nota2=eval(nota2)
let nota3 = prompt("Digite a 3º nota:");
nota3=eval(nota3)
let nota4 = prompt("Digite a 4º nota:");
nota4=eval(nota4)
let media = (nota1+nota2+nota3+nota4)/4
alert(media)