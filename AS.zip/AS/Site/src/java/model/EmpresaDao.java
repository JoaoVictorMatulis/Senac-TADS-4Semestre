package model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class EmpresaDao {
    private EntityManagerFactory factory;
    private EntityManager manager;
    
    private void conectar(){
        factory = Persistence.createEntityManagerFactory("SitePU");
        manager = factory.createEntityManager();
    }
}
