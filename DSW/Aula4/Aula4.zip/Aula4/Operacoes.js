export function calcularMedia(n1,n2,n3){
    let m = (n1+n2+n3)/3
    return m
}

export function verificarMedia(m){
    return m >= 6 ? 'Passou' : 'DP';

}