import './index.scss';
import { Link } from 'react-router-dom';


export default function Sobre() {


  return (
    <div className='pagina-sobre'>
      <h1> Sobre </h1>
      <hr />
      <Link to='/'> Voltar Home </Link>

    </div>
  )
  
}