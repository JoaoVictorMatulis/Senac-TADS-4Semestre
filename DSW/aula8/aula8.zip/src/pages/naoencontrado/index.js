export default function NaoEncontrado() {

    return (
      <div>
        <h1> PÁGINA NÃO ENCONTRADA</h1>
      </div>
    )
  }