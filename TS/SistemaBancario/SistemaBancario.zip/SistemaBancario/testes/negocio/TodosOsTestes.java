package negocio;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/* 
 * Teste de Classe 
 * Aluno: João Victor Matulis 
 * Data: 06/09/2023
 * */

@RunWith(Suite.class)
@SuiteClasses({GerenciadoraClientesTest.class, GerenciadoraContasTest.class})
public class TodosOsTestes {

}
